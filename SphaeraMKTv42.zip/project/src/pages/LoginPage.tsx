import React from 'react';
import { LoginForm } from '../components/LoginForm';

export function LoginPage() {
  return <LoginForm />;
}
// Use relative URL when using Vite's proxy
export const API_BASE_URL = '/api';